        <!-- sidebar -->
<div id="sidebar">
    <?php dynamic_sidebar('left_sidebar'); ?>
</div>